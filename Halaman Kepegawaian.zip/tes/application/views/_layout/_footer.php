<footer class="main-footer">
	<!-- To the right -->
	<div class="pull-right hidden-xs">
		Dashboard Admin
	</div>
	<!-- Default to the left -->
	<strong>Copyright &copy; 2023 <a href="#">JTTC</a>.</strong> All rights reserved.
</footer>