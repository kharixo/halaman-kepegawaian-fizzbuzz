<?php
  $no = 1;
  foreach ($datakontrak as $kontrak) {
    ?>
    <tr>
      <td><?php echo $no; ?></td>
      <td><?php echo $kontrak->nama; ?></td>
      <td class="text-center" style="min-width:230px;">
          <button class="btn btn-warning update-datakontrak" data-id="<?php echo $kontrak->id; ?>"><i class="glyphicon glyphicon-repeat"></i> Update</button>
          <button class="btn btn-danger konfirmasiHapus-kontrak" data-id="<?php echo $kontrak->id; ?>" data-toggle="modal" data-target="#konfirmasiHapus"><i class="glyphicon glyphicon-remove-sign"></i> Delete</button>
          <button class="btn btn-info detail-datakontrak" data-id="<?php echo $kontrak->id; ?>"><i class="glyphicon glyphicon-info-sign"></i> Detail</button>
      </td>
    </tr>
    <?php
    $no++;
  }
?>